##############################################
############ Meta Game Language ##############
###############Individual#####################

##############################################
# By:                                        #
#    Sune Chung Jepsen                       #
##############################################

This zip contains:

- version_individual
  - dsl folder
    - Contains the custom extension files (.mgl)
 
  - framework folder
    - Zipped source code of the framework code.
    - gameframework.jar that is needed for the
      generated java code.

  - xtext folder
    - Contains .xtext and .xtend files

- version_group
  - Contains the group project
  - Has its own README.txt
  


 


