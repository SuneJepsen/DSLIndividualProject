##############################################
############ Meta Game Language ##############
##############################################

##############################################
# By:                                        #
#    Admir Muric                             #
#    Anna �lgaard Nielsen                    #
#    Sune Chung Jepsen                       #
##############################################

This zip contains:
 
- dsl folder
  - Contains the custom extension files (.mgl)
 
- framework folder
  - Zipped source code of the framework code.
  - gameframework.jar that is needed for the
    generated java code.

 - xtext folder
  - Contains .xtext and .xtend files

 - A HowToVideo.mp4
  - Showcases how to setup everything to run the
    examples.
  - At timestamp 4:25 an example is run.
  - The video is 5:22 minutes long.
