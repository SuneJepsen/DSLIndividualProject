package com.frameworkdsl.fluentapi;

import com.frameworkdsl.gameframework.DSLFrameworkConstants;
import com.frameworkdsl.fluentapi.callback.IPropertyCallback;
import com.frameworkdsl.fluentapi.callback.IWinningCallback;
import com.frameworkdsl.metamodel.graph.MetaGameGraph;
import com.frameworkdsl.metamodel.MachineMetaModel;
import com.frameworkdsl.objects.Location;
import com.frameworkdsl.objects.Object;
import com.frameworkdsl.objects.Position;

import java.util.List;
import java.util.Map;

public abstract class FluentMachine   {

    public enum Effect { SET, CHANGE }
    public enum Condition { EQUAL, GREATER }
    public MachineMetaModel metamodel = new MachineMetaModel();
    private Object currentObject;
    private Location currentLocation;
    private String globalVariableName;


    protected abstract void build();

    protected void buildMachine() { // test
        System.out.println("buildMachine in FluentMachine called");
        build();
        end();
    }
    public FluentMachine end() {
        MetaGameGraph graph = metamodel.getGraph();
        Map<String,java.lang.Object> map = metamodel.getExtendedStateVariables();
        for (Map.Entry e : map.entrySet()) {
            graph.execute((String)e.getKey());
        }
        return this;
    }

    public FluentMachine object(String name, int x, int y) {
        flushLocation();
        flushGlobalVariableName();
        currentObject = new Object(name,new Position(x,y));
        metamodel.getAllObjects().add(currentObject);
        return this;
    }
    public FluentMachine location(String name, List<Position> positions) {
        flushObject();
        flushGlobalVariableName();
        currentLocation = new Location(name, positions);
        metamodel.getAllLocations().add(currentLocation);
        return this;
    }
    public FluentMachine global(String name){
        globalVariableName = name;
        return this;
    }
    public FluentMachine intProperty(String name, int propertyValue) {
    	addProperty(name, propertyValue);
        return this;
    }
    public FluentMachine boolProperty(String name, boolean propertyValue) {
    	addProperty(name, propertyValue);
        return this;
    }
    public FluentMachine winningState(IWinningCallback winningCallback){
        metamodel.getExtendedStateVariables().put(DSLFrameworkConstants.getWinningStateName(),winningCallback);
        return this;
    }
    public FluentMachine varProperty(String name, String[] variables, IPropertyCallback callback) {
        try {
            String objectLocationName = "";

            if(currentObject!= null){
                objectLocationName = currentObject.getName()+ "." +name;
            }else{
                objectLocationName = currentLocation.getName()+ "." +name;
            }
            metamodel.addNode(objectLocationName, callback);
            for (String v : variables) {
                metamodel.addEdge(v, objectLocationName);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return this;
    }
    // TODO: Do not add any properties on objects/locations - only add "Agent1.isAgent" to the extendedStates
    private void addProperty(String name, java.lang.Object propertyValue){
        if(globalVariableName != ""){
            metamodel.getExtendedStateVariables().put(name,propertyValue);
            return;
        }
        if(currentObject==null && currentLocation== null)throw new Error("Undefined object or location");

        String objectLocationName = "";

        if(currentObject!= null){
            objectLocationName = currentObject.getName()+ "." +name;
        }else{
            objectLocationName = currentLocation.getName()+ "." +name;
        }

        metamodel.getExtendedStateVariables().put(objectLocationName,propertyValue);
    }
    private void flushLocation() {
        currentLocation = null;
    }
    private void flushObject() {
        currentObject = null;
    }
    private void flushGlobalVariableName() {
        globalVariableName = "";
    }

}