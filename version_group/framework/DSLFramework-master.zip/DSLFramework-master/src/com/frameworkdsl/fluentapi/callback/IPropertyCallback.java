package com.frameworkdsl.fluentapi.callback;

public interface IPropertyCallback {

    void execute();
}
