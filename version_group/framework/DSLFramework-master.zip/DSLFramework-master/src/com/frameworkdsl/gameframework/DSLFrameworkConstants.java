package com.frameworkdsl.gameframework;

public  class DSLFrameworkConstants {
    private static   String _winningStateName = "winningState";


    public static String getWinningStateName() {
        return _winningStateName;
    }


}
