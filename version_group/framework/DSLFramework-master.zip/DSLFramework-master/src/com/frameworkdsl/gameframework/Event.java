package com.frameworkdsl.gameframework;

import java.util.List;

public class Event {
    private  List<java.lang.Object> _eventArgs;
    private IAction _action;

    public Event(List<java.lang.Object> eventArgs,  IAction action){
       _eventArgs = eventArgs;
        _action = action;
    }

    public IAction getAction() {
        return _action;
    }

    public List<java.lang.Object> getEventArgs() {
        return _eventArgs;
    }
}
