package com.frameworkdsl.gameframework;

import com.frameworkdsl.objects.Location;
import com.frameworkdsl.objects.Object;
import com.frameworkdsl.objects.Position;

public class FrameworkPredefinedInternalFunction implements IInternalFunction {
    @Override
    public boolean isNeighbor(Object object, Location location) {
        Position objectPosition = object.getPosition();
        Position nextPosition = location.getPositions().get(0);
        if(objectPosition.X+1 == nextPosition.X && objectPosition.Y == nextPosition.Y){ // go down
            return true;
        }
        if(objectPosition.X-1 == nextPosition.X && objectPosition.Y == nextPosition.Y){ // go up
            return true;
        }
        if(objectPosition.X == nextPosition.X && objectPosition.Y+1 == nextPosition.Y){ // go right
            return true;
        }
        if(objectPosition.X == nextPosition.X && objectPosition.Y-1 == nextPosition.Y){ // go left
            return true;
        }
        return false;

    }
    @Override
    public Object goTo(Object object, Location location) {
        object.setPosition(location.getPositions().get(0));
        return object;
    }

    @Override
    public boolean isHere(Object object, Location location) {
        Position objectPosition = object.getPosition();
        for (Position p : location.getPositions()) {
	        if(objectPosition.Y == p.Y && objectPosition.X == p.X){
	            return true;
	        }
	    }
        return false;
    }

    @Override
    public boolean isHere(Object object1, Object object2) {
        Position objectPosition1 = object1.getPosition();
        Position objectPosition2 = object2.getPosition();
        if(objectPosition1.Y == objectPosition2.Y && objectPosition1.X == objectPosition2.X){
            return true;
        }
        return false;
    }
	@Override
	public boolean isNeighbor(Location location, Location location2) {
        Position locationPosition = location.getPositions().get(0);
        Position nextPosition = location2.getPositions().get(0);
        if(locationPosition.X+1 == nextPosition.X && nextPosition.Y == nextPosition.Y){ // go down
            return true;
        }
        if(locationPosition.X-1 == nextPosition.X && nextPosition.Y == nextPosition.Y){ // go up
            return true;
        }
        if(locationPosition.X == nextPosition.X && nextPosition.Y+1 == nextPosition.Y){ // go right
            return true;
        }
        if(locationPosition.X == nextPosition.X && nextPosition.Y-1 == nextPosition.Y){ // go left
            return true;
        }
        return false;
	}
	@Override
	public boolean isNeighbor(Object object, Object object2) {
        Position objectPosition = object.getPosition();
        Position nextPosition = object2.getPosition();
        if(objectPosition.X+1 == nextPosition.X && objectPosition.Y == nextPosition.Y){ // go down
            return true;
        }
        if(objectPosition.X-1 == nextPosition.X && objectPosition.Y == nextPosition.Y){ // go up
            return true;
        }
        if(objectPosition.X == nextPosition.X && objectPosition.Y+1 == nextPosition.Y){ // go right
            return true;
        }
        if(objectPosition.X == nextPosition.X && objectPosition.Y-1 == nextPosition.Y){ // go left
            return true;
        }
        return false;
	}
	@Override
	public Object goTo(Object object, Object object2) {
        object.setPosition(object2.getPosition());
        return object;
	}
}
