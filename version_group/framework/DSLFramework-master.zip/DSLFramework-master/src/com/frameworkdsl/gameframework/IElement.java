package com.frameworkdsl.gameframework;

import com.frameworkdsl.objects.Position;

public interface IElement {
    Position getPosition();
    String getName();
}
