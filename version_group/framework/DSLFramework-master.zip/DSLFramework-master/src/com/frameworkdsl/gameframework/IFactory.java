package com.frameworkdsl.gameframework;

import com.frameworkdsl.executor.IStateMachineExecuter;
import com.frameworkdsl.gui.IGui;
import com.frameworkdsl.metamodel.MachineMetaModel;

public interface IFactory {
	IStateMachineExecuter getStateMachineExecuter();
	IGui getGui();
	MachineMetaModel getMetaModel();
}
