package com.frameworkdsl.gameframework;

import java.util.List;

public interface IFramework {
    void run(List<Event> events);
}
