package com.frameworkdsl.gameframework;

public interface IGame {
	void Update();
}
