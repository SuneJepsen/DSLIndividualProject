package com.frameworkdsl.gui;

import com.frameworkdsl.objects.IState;
import com.frameworkdsl.objects.Location;
import com.frameworkdsl.objects.Object;
import com.frameworkdsl.objects.Position;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class GraphicalUserInterface extends JFrame implements IGui {

	private final int WIDTH = 800, HEIGHT = 800;
	private int _rows, _columns;
	private JPanel panel;
	
	public GraphicalUserInterface(int rows, int columns) {
		super("Meta Game");
		_rows = rows;
		_columns = columns;
	}
	
	public GraphicalUserInterface(String name, int rows, int columns) {
		super(name);
		_rows = rows;
		_columns = columns;
	}
	
	private void initPanel() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		
		panel = new JPanel(new GridLayout(_rows, _columns));
		panel.setPreferredSize(getPreferredSize());
		for (int i = 0; i < _rows*_columns; i++) {
			JLabel label = new JLabel("", SwingConstants.CENTER);
			label.setSize(new Dimension(WIDTH/_columns, HEIGHT/_rows));
			label.setBorder(LineBorder.createGrayLineBorder());
			label.setFont(new Font(label.getName(), Font.PLAIN, 25));
			panel.add(label, i);
		}
	}
	
	@Override
	public void update(IState state) {
		initPanel();
		
		for (Location l : state.getLocations()) {
			for (Position p : l.getPositions()) {
				int index = p.Y*_columns + p.X;
				JLabel label = (JLabel)panel.getComponent(index);
				String text = label.getText().replace("<html>", "").replace("</html>", "");
				if (text != "") text += "<br/>";
				label.setText("<html>" + text + l.getName() + "</html>");
				panel.add(label, index);	
			}
		}
		
		for (Object o : state.getObjects()) {
			int index = o.getPosition().Y*_columns + o.getPosition().X;
			JLabel label = (JLabel)panel.getComponent(index);
			String text = label.getText().replace("<html>", "").replace("</html>", "");
			if (text != "") text += "<br/>";
			label.setText("<html>" + text + o.getName() + "</html>");
			panel.add(label, index);
		}
		
		getContentPane().add(panel, BorderLayout.CENTER);
		pack();
		setVisible(true);
		
		// Sleep for 1 sec for showing all states
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

/* For testing purposes!
	public static void main(String[] args) {
		GraphicalUserInterface test = new GraphicalUserInterface(4,4);
		List<Object> objects = new ArrayList<Object>() {{ add(new Object("Agent1", new Position(2,2))); add(new Object("Agent2", new Position(1,1))); }};
		List<Location> locations = new ArrayList<Location>() {{ add(new Location("Wall", new ArrayList<Position>() {{ add(new Position(0,0)); add(new Position(1,0)); }})); }};
		IState state = new Board("initial state", objects, locations);
		test.update(state);
		
		objects.add(new Object("Agent3", new Position(0,0)));
		objects.add(new Object("Agent4", new Position(0,0)));
		test.update(new Board("next state", objects, locations));
	}*/
}
