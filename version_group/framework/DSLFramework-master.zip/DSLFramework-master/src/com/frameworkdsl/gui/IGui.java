package com.frameworkdsl.gui;

import com.frameworkdsl.objects.IState;

public interface IGui {
	void update(IState state);
}
