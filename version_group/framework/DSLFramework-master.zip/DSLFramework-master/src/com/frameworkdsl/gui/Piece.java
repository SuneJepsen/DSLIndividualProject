package com.frameworkdsl.gui;

import com.frameworkdsl.gameframework.IElement;
import com.frameworkdsl.objects.Position;

public class Piece implements IElement {

    private final Position _position;
    private final String _name;

    public Piece(Position position, String name){
        _position = position;
        _name = name;
    }

    @Override
    public Position getPosition() {
        return _position;
    }

    @Override
    public String getName() {
        return _name;
    }
}
