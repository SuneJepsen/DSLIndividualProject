package com.frameworkdsl.gui;

import com.frameworkdsl.gameframework.IElement;
import com.frameworkdsl.objects.IState;
import com.frameworkdsl.objects.Location;
import com.frameworkdsl.objects.Object;
import com.frameworkdsl.objects.Position;

import java.util.ArrayList;
import java.util.List;

public class TwoDimensionalGui implements IGui{
	private  int _rows;
	private int _columns;

	public TwoDimensionalGui(int rows, int columns) {
		_rows = rows;
		_columns= columns;
	}
	@Override
	public void update(IState state) {
		/******************/
		/*Build gui*/
		/******************/
        // an entry should have a list of elements, meaning that we can
        // illustrate to have more elements on a position of the grid
        // eventually there might be an validation rule if this is legal
        List<Location> locations = state.getLocations();
        List<Object> objects = state.getObjects();
        List<IElement>[][] grid = new ArrayList[_rows][_columns];
        for(Location location: locations){
            for(Position postion: location.getPositions()){
                List<IElement> elements = grid[postion.X][postion.Y];
                if(elements == null){
                    grid[postion.X][postion.Y]= new ArrayList<IElement>(){{add(new Piece(new Position(postion.X,postion.Y),location.getName()));}};
                }else{
                    elements.add(new Piece(new Position(postion.X,postion.Y),location.getName()));
                }

            }
        }
        for(Object object: objects){
            List<IElement> elements = grid[object.getPosition().X][object.getPosition().Y];
            if(elements == null){
                grid[object.getPosition().X][object.getPosition().Y]= new ArrayList<IElement>(){{add(new Piece(new Position(object.getPosition().X,object.getPosition().Y),object.getName()));}};
            }else{
                elements.add(new Piece(new Position(object.getPosition().X,object.getPosition().Y),object.getName()));
            }
        }


        /*Show gui*/
        System.out.println();
        System.out.println();
        System.out.println("*************** " +state.getName()+ " ***************");
        for (int i = 0; i < _rows; i++)
        {
            System.out.println();
            for (int j = 0; j < _columns; j++)
            {
                List<IElement> elements = grid[i][j];

                if(elements == null){
                    System.out.print("-      ");
                }else{
                    String value = "";
                    for(IElement e:elements){
                        value += e.getName() + ",";
                    }
                    System.out.print("{" +value.substring(0, value.length() - 1) +"}");
                }
            }
        }
        System.out.println();
        System.out.println();
		
	}

}
