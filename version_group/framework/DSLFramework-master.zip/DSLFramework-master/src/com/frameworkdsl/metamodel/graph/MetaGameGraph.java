package com.frameworkdsl.metamodel.graph;

import com.frameworkdsl.fluentapi.callback.IPropertyCallback;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MetaGameGraph {

    class GraphNode {

        private String name;
        private IPropertyCallback callback;

        public GraphNode(String name, IPropertyCallback callback) {
            this.name = name;
            this.callback = callback;
        }

        public void execute() {
            callback.execute();
        }

    }

    private Map<String, List<GraphNode>> graph;

    public MetaGameGraph () {
        graph = new HashMap<>();
    }

    public void addNode(String name, IPropertyCallback callback) {
        GraphNode node = new GraphNode(name, callback);
        List<GraphNode> list;
        if (graph.containsKey(name)) {
            list = graph.get(name);
        } else {
            list = new LinkedList<GraphNode>();
        }
        list.add(0,node);
        graph.put(name, list);
    }

    public void addEdge(String parent, String child) throws Exception {
    	//System.out.println("edge: " + parent + ", " + child);
        if (!graph.containsKey(child)) {
            throw new Exception("Child does not exist in map");
        }
        List<GraphNode> list;
        if (!graph.containsKey(parent)) {
        	//System.out.println("new list to node: " + parent);
            list = new LinkedList<GraphNode>();
        } else {
            list = graph.get(parent);
        }
        list.add(graph.get(child).get(0));
        graph.put(parent, list);
    }

    public void execute(String startNode) {
    	//System.out.println("execute on " + startNode);
        List<GraphNode> children = graph.get(startNode);
        if(children == null) return;
        //System.out.println("number of children "+children.size());
        for (GraphNode child : children) {
        	if (!child.name.equals(startNode)) {
            	//System.out.println("child: "+child.name);
                child.execute(); // Execute child
                //System.out.println("children");
                execute(child.name); // Execute all childs children	
        	}
        }
    }

}
