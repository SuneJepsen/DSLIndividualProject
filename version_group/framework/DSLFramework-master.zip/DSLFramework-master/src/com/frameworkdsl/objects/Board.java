package com.frameworkdsl.objects;

import java.util.List;

public class Board implements IState {
    private final boolean _isInWinningState;
    private String _name;
    // Create a list with objects
    private List<Object> _objects;
    // Create a list with all locations
    private List<Location> _locations;

     public Board(String name, List<Object> objects, List<Location> locations, boolean isInWinningState) {
        _name = name;
        _objects = objects;
        _locations = locations;
        _isInWinningState = isInWinningState;
     }


    @Override
    public List<Location> getLocations() {
        return _locations;
    }

    @Override
    public List<Object> getObjects() {
        return _objects;
    }

    @Override
    public String getName() {
        return _name;
    }

    @Override
    public Boolean getIsInWinningState() {
        return _isInWinningState;
    }
}