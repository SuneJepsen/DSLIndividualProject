package com.frameworkdsl.objects;

import java.util.List;

public class Location {
    private String _name;
    //private Map<String,java.lang.Object> _properties;
    private List<Position> _positions;

    public Location(String name, List<Position> positions){
        _name= name;
        _positions = positions;
        //_properties = new HashMap<>();
    }

    public List<Position> getPositions() {
        return _positions;
    }
//    public void addProperty(String key, java.lang.Object value) {
//        _properties.put(key,value);
//    }
//    public Map<String,java.lang.Object> getProperties(){
//        return _properties;
//    }

    public String getName() {
        return _name;
    }
}
