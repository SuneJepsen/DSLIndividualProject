package com.frameworkdsl;
import com.frameworkdsl.gameframework.*;
import com.frameworkdsl.fluentapi.callback.*;
import com.frameworkdsl.metamodel.graph.*;
import com.frameworkdsl.fluentapi.*;
import com.frameworkdsl.metamodel.MachineMetaModel;
import com.frameworkdsl.objects.Location;
import com.frameworkdsl.objects.Position;
import com.frameworkdsl.objects.Object;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*
* This class serves as a test runner for testing the framework
*
*/
public class RunnerWithDelete extends FluentMachine {
    public class MoveAction implements IAction{
        private IInternalFunction _iInternalFunction;;

        public MoveAction(IInternalFunction iInternalFunction){
            _iInternalFunction = iInternalFunction;
        }

        @Override
        public boolean execute(Map<String, java.lang.Object> args, MachineMetaModel model) {
            boolean executionAllowed = true;
            Map<String,java.lang.Object> map = model.getExtendedStateVariables();
            MetaGameGraph graph = model.getGraph();
            Object player = (Object)args.get("player");
            Location next = (Location )args.get("next");
            executionAllowed &= (map.containsKey(player.getName()+".isAgent") && (boolean)map.get(player.getName()+".isAgent"))
                    || !map.containsKey(player.getName()+".isAgent");;
            executionAllowed &= (map.containsKey(next.getName()+".isWall") && !(boolean)map.get(next.getName()+".isWall"))
                    || !map.containsKey(next.getName()+".isWall");;
            executionAllowed &= !_iInternalFunction.isNeighbor(model.getObject("Goal"), next);;
            executionAllowed &= _iInternalFunction.isNeighbor(player, next);;
            if(executionAllowed) {
                // delete

                _iInternalFunction.goTo(player, next);

                if (map.containsKey(player.getName()+".score")) map.put(player.getName()+".score", (int)map.get(player.getName()+".score") + 1);
                graph.execute(player.getName()+".score");
                if (map.containsKey(player.getName()+".x")) map.put(player.getName()+".x", (int)map.get(player.getName()+".x") + 1);
                graph.execute(player.getName()+".x");
            }
            return executionAllowed;
        }

        @Override
        public List<String> getTypeList() {
            List<String> types = new ArrayList<>();
            types.add("player");
            types.add("next");
            return types;
        }
    }
    public class DeleteAction implements IAction{
        private IInternalFunction _iInternalFunction;;

        public DeleteAction(IInternalFunction iInternalFunction){
            _iInternalFunction = iInternalFunction;
        }

        @Override
        public boolean execute(Map<String, java.lang.Object> args, MachineMetaModel model) {
            boolean executionAllowed = true;
            Map<String,java.lang.Object> map = model.getExtendedStateVariables();
            MetaGameGraph graph = model.getGraph();
            Object player = (Object)args.get("player");
            Location next = (Location )args.get("next");
            executionAllowed &= (map.containsKey(player.getName()+".isAgent") && (boolean)map.get(player.getName()+".isAgent")) || !map.containsKey(player.getName()+".isAgent");
            executionAllowed &= (map.containsKey(next.getName()+".isWall") && (boolean)map.get(next.getName()+".isWall"))|| !map.containsKey(next.getName()+".isWall");

            executionAllowed &= _iInternalFunction.isNeighbor(player, next);;
            if(executionAllowed) {
                 _iInternalFunction.goTo(player, next);

                 // delete in object
                List<Object>objectsToRemove = new ArrayList<>();
                for(int i=0; i<model.getAllObjects().size(); i++){
                    if(model.getAllObjects().get(i).getPosition().X == next.getPositions().get(0).X &&
                            model.getAllObjects().get(i).getPosition().Y == next.getPositions().get(0).Y &&
                            model.getAllObjects().get(i).getName() != player.getName() &&
                            model.getAllObjects().get(i).getName() != "Goal"){
                        objectsToRemove.add(model.getAllObjects().get(i));
                        System.out.println("delete object in objects");
                    }
                }
                model.getAllObjects().removeAll(objectsToRemove);

                // delete in location
                List<Position>positionsToRemove = new ArrayList<>();
                for(int i=0; i<model.getAllLocations().size(); i++){
                    for(int y=0; y<model.getAllLocations().get(i).getPositions().size(); y++){
                        if(model.getAllLocations().get(i).getPositions().get(y).X == next.getPositions().get(0).X &&
                                model.getAllLocations().get(i).getPositions().get(y).Y == next.getPositions().get(0).Y ){
                            positionsToRemove.add(model.getAllLocations().get(i).getPositions().get(y));
                            System.out.println("delete wall in location");
                        }
                    }
                    model.getAllLocations().get(i).getPositions().removeAll(positionsToRemove);
                }


            }
            return executionAllowed;
        }

        @Override
        public List<String> getTypeList() {
            List<String> types = new ArrayList<>();
            types.add("player");
            types.add("next");
            return types;
        }
    }
    private MachineMetaModel _machineMetaModel;
    private List<Event> events = new ArrayList<>();
    private IAction action = new MoveAction(new FrameworkPredefinedInternalFunction());
    private RunnerWithDelete(){
        buildMachine();
        run();
    }
    public void build(){
        // Create object tree
        Map<String, java.lang.Object> map = metamodel.getExtendedStateVariables();


        global("Labyrint4").varProperty("tscore", new String[] {"Agent1.score", "Agent2.score"}, new IPropertyCallback() {
            @Override
            public void execute() {
                map.put("tscore", (int) map.get("Agent1.score") + (int) map.get("Agent2.score"));
            }
        })
        .object("Agent1",0,3).boolProperty("isAgent", true).intProperty("score", 0)
        .object("Agent2",3,0).boolProperty("isAgent", true).intProperty("score", 0)
        .object("Agent3",1,1).boolProperty("isAgent", true).intProperty("score", 0)
        .location("Wall", new ArrayList<Position>()  {{ add(new Position(1,2));add(new Position(2,2));}}).boolProperty("isWall", true)
        .object("Goal", 0,2)
        .winningState(new IWinningCallback() {
            @Override
            public boolean execute(MachineMetaModel machineMetaModel, IInternalFunction internalFunction) {
                boolean hasWon =true;
                hasWon &= internalFunction.isHere(machineMetaModel.getObject("Agent1"), machineMetaModel.getObject("Goal"));
                //hasWon &= (int)machineMetaModel.getExtendedStateVariables().get("tscore") > 10;
                hasWon &= (boolean)machineMetaModel.getExtendedStateVariables().get("Agent1.isAgent");
                return hasWon;
            }
        });

        // Create events
        events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(1, 3)); }}, new MoveAction(new FrameworkPredefinedInternalFunction())));
        events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(1, 2)); }}, new DeleteAction(new FrameworkPredefinedInternalFunction())));
        events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(1, 1)); }}, new DeleteAction(new FrameworkPredefinedInternalFunction())));
        events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(0, 1)); }}, new DeleteAction(new FrameworkPredefinedInternalFunction())));
        events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(0, 2)); }}, new DeleteAction(new FrameworkPredefinedInternalFunction())));
        //events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(2, 3)); }}, new MoveAction(new FrameworkPredefinedInternalFunction())));
        //events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(2, 2)); }}, new MoveAction(new FrameworkPredefinedInternalFunction())));
        //events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(2, 1)); }}, new MoveAction(new FrameworkPredefinedInternalFunction())));
        //events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(1, 1)); }}, new MoveAction(new FrameworkPredefinedInternalFunction())));
        //events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(0, 1)); }}, new MoveAction(new FrameworkPredefinedInternalFunction())));
        //events.add(new Event(new ArrayList<java.lang.Object>() {{ add("Agent1"); add(new Position(0, 2)); }}, new MoveAction(new FrameworkPredefinedInternalFunction())));
        _machineMetaModel = metamodel;
    }

    public void run(){
        IFramework framework = new GameFramework(new GameFrameworkFactory(_machineMetaModel, new FrameworkPredefinedInternalFunction()));
        framework.run(events);
    }

    public static void main(String [] args)
    {
        new RunnerWithDelete();
    }
}


