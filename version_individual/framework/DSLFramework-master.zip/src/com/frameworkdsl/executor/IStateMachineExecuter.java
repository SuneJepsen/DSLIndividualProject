package com.frameworkdsl.executor;

import com.frameworkdsl.objects.IState;
import com.frameworkdsl.gameframework.Event;

public interface IStateMachineExecuter {
	IState getInitialState();
	IState processEvent(Event event);
}
