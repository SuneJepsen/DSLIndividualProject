package com.frameworkdsl.executor;

import com.frameworkdsl.objects.Board;
import com.frameworkdsl.objects.IState;
import com.frameworkdsl.fluentapi.callback.IWinningCallback;
import com.frameworkdsl.gameframework.DSLFrameworkConstants;
import com.frameworkdsl.gameframework.Event;
import com.frameworkdsl.gameframework.IInternalFunction;
import com.frameworkdsl.metamodel.MachineMetaModel;
import com.frameworkdsl.objects.Location;
import com.frameworkdsl.objects.Position;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class StateMachineExecuter implements IStateMachineExecuter {
       private MachineMetaModel _machineMetaModel;
       private IState _currentState;
       private IInternalFunction _iInternalFunction;


       public StateMachineExecuter(MachineMetaModel machineMetaModel, IInternalFunction iInternalFunction)
       {
              _machineMetaModel= machineMetaModel;
              _iInternalFunction = iInternalFunction;
       }
       public IState getInitialState()
       {
              _currentState = new Board("Initial state",_machineMetaModel.getAllObjects(),_machineMetaModel.getAllLocations(), false);
              return _currentState;
       }
       public IState processEvent(Event event)
       {
              List<java.lang.Object> eventArgs =  event.getEventArgs();
              Map<String,java.lang.Object> actionMap = new HashMap<>();
              if(eventArgs != null){
                     List<String> typeList = event.getAction().getTypeList();

                     if(typeList != null){
                            // typelist contains player, next , .....
                            for (int i=0; i<typeList.size(); i++){
                                   java.lang.Object eventArgObject = eventArgs.get(i);

                                   if(eventArgObject instanceof String){
                                         // String
                                          actionMap.put(typeList.get(i), _machineMetaModel.getObject((String)eventArgs.get(i)));
                                   }else{
                                         // Position
                                          Position nextPosition = (Position) eventArgObject;
                                          Location nextlocation = new Location("empty", new ArrayList<Position>(){{add(nextPosition);}});
                                          for(Location location: _machineMetaModel.getAllLocations()){
                                                 System.out.print(location.getName() + ": ");
                                                 for(Position position: location.getPositions()){
                                                        System.out.print("("+position.X+", "+position.Y+")" );
                                                        if(position.X == nextPosition.X && position.Y == nextPosition.Y){
                                                               nextlocation = location;
                                                               break;
                                                        }
                                                 }
                                          }
                                          actionMap.put(typeList.get(i),nextlocation );
                                   }
                            }
                     }

              }

              // execute the action
              boolean pass = event.getAction().execute(actionMap,  _machineMetaModel);

              // check for winning state
              java.lang.Object objectWinningState = _machineMetaModel.getExtendedStateVariables().get(DSLFrameworkConstants.getWinningStateName());
              boolean isInWinningState = false;
              if(objectWinningState != null){
                     IWinningCallback winningCallback = (IWinningCallback)objectWinningState;
                     if(winningCallback != null){
                            isInWinningState = winningCallback.execute(_machineMetaModel,_iInternalFunction);
                     }
              }


              for (Entry e : _machineMetaModel.getExtendedStateVariables().entrySet()) {
            	  System.out.print((String)e.getKey() + ": " + e.getValue() + ", ");
              }
              System.out.println();

              // if when well create a new state based on the updated object and metamodel
              if(!pass){ System.out.println("*************** Illegal action ***************");}
              if(isInWinningState) System.out.println("***************** you win *****************");

              _currentState = new Board("action executed",_machineMetaModel.getAllObjects(),_machineMetaModel.getAllLocations(),isInWinningState);
              _machineMetaModel.getAllStates().add(_currentState);
              _machineMetaModel.getAllEvents().add(event);
              return _currentState;
       }

}
