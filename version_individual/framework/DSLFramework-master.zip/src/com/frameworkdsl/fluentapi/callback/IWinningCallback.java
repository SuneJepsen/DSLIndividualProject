package com.frameworkdsl.fluentapi.callback;

import com.frameworkdsl.gameframework.IInternalFunction;
import com.frameworkdsl.metamodel.MachineMetaModel;

public interface IWinningCallback {
    boolean execute(MachineMetaModel machineMetaModel, IInternalFunction internalFunction);
}
