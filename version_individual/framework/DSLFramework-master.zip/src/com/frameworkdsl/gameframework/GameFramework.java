package com.frameworkdsl.gameframework;

import com.frameworkdsl.objects.IState;
import com.frameworkdsl.executor.IStateMachineExecuter;
import com.frameworkdsl.gui.IGui;
import com.frameworkdsl.metamodel.MachineMetaModel;

import java.util.List;

public class GameFramework implements IFramework {

    private IGui _gui;
    private IStateMachineExecuter _stateMachineExecuter;
    private MachineMetaModel _metaModel;

    public GameFramework(IFactory factory) {
        _gui = factory.getGui();
        _stateMachineExecuter = factory.getStateMachineExecuter();
        _metaModel = factory.getMetaModel();
        update(_stateMachineExecuter.getInitialState());
    }

    public void run(List<Event> events) {
        for (Event e : events) {
            update( _stateMachineExecuter.processEvent(e));
        }
    }

    private void update(IState state) {
        _gui.update(state);
    }
}
