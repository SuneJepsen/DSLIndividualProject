package com.frameworkdsl.gameframework;

import com.frameworkdsl.executor.IStateMachineExecuter;
import com.frameworkdsl.executor.StateMachineExecuter;
import com.frameworkdsl.gui.GraphicalUserInterface;
import com.frameworkdsl.gui.IGui;
import com.frameworkdsl.metamodel.MachineMetaModel;

public class GameFrameworkFactory implements IFactory {
	private IGui _gui;
	private IStateMachineExecuter _stateMachineExecuter;
	private MachineMetaModel _machineMetaModel;
	private IInternalFunction _iInternalFunction;

	public GameFrameworkFactory (MachineMetaModel machineMetaModel, IInternalFunction _iInternalFunction) {
		_machineMetaModel = machineMetaModel;
		//_gui = new TwoDimensionalGui(4,4); // ToDo: Refactor to be dynamic
		_gui = new GraphicalUserInterface(4,4);
		_stateMachineExecuter = new StateMachineExecuter(machineMetaModel, _iInternalFunction);
	}
	public IGui getGui() {
		return _gui;
	}
	public IStateMachineExecuter getStateMachineExecuter() {
		return _stateMachineExecuter;
	}
	public MachineMetaModel getMetaModel() {
		return _machineMetaModel;
	}
}
