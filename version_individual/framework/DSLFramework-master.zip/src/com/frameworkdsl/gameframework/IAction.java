package com.frameworkdsl.gameframework;

import com.frameworkdsl.metamodel.MachineMetaModel;

import java.util.List;
import java.util.Map;

public interface IAction {
    boolean execute(Map<String, java.lang.Object> args, MachineMetaModel model);
   // boolean execute(Object object, Location location,Map<String,java.lang.Object> map, MetaGameGraph graph);
    List<String> getTypeList();
}
