package com.frameworkdsl.gameframework;

import com.frameworkdsl.objects.Location;
import com.frameworkdsl.objects.Object;

public interface IInternalFunction {
    boolean isNeighbor(Object object, Location location);
    boolean isNeighbor(Location location, Location location2);
    boolean isNeighbor(Object object, Object object2);
    Object goTo(Object object, Location location);
    Object goTo(Object object, Object object2);
    boolean isHere(Object object, Location location);
    boolean isHere(Object object1, Object object2);
}
