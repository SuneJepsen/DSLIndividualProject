package com.frameworkdsl.metamodel;
import com.frameworkdsl.gameframework.Event;
import com.frameworkdsl.objects.IState;
import com.frameworkdsl.fluentapi.callback.IPropertyCallback;
import com.frameworkdsl.metamodel.graph.MetaGameGraph;
import com.frameworkdsl.objects.Location;
import com.frameworkdsl.objects.Object;

import java.util.*;

public class MachineMetaModel {

    private Map<String,java.lang.Object> _extendedStateVariables;
    // The complete list of all states (first is assumed To be initial)
    private  List<IState> _allStates;
    private  List<Event> _allEvents;
    private  List<Object> _allObjects;
    private  List<Location> _allLocations;
    private MetaGameGraph _graph;

    public MachineMetaModel()
    {

        _extendedStateVariables = new HashMap<>();
        _allStates = new ArrayList<IState>();
        _allLocations = new ArrayList<Location>();
        _allObjects = new ArrayList<Object>();
        _allEvents = new ArrayList<Event>();
        _graph = new MetaGameGraph();
    }

    public List<IState> getAllStates()
    {
        return _allStates;
    }
    public List<Object> getAllObjects()
    {
        return _allObjects;
    }
    public List<Location> getAllLocations() { return _allLocations; }
    public Map<String,java.lang.Object> getExtendedStateVariables() { return _extendedStateVariables; }
    public MetaGameGraph getGraph() { return _graph; }

    public List<Event> getAllEvents() {
        return _allEvents;
    }

    public Object getObject(String objectId){
        Object returnObject= null;
        for(Object object:_allObjects){
            if(object.getName() == objectId){
                returnObject = object;
                break;
            }
        }
        return returnObject;
    }

    public Location getLocation(String locationId){
        Location returnLocation= null;
        for(Location location:_allLocations){
            if(location.getName() == locationId){
                returnLocation = location;
                break;
            }
        }
        return returnLocation;
    }

    public void addNode(String name, IPropertyCallback callback) throws Exception {
        _graph.addNode(name, callback);
    }

    public void addEdge(String parent, String child) throws Exception {
        _graph.addEdge(parent, child);
    }
}
