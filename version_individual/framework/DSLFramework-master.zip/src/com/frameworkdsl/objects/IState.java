package com.frameworkdsl.objects;

import java.util.List;

public interface IState {
    List<Location> getLocations();
    List<Object> getObjects();
    String getName();
    Boolean getIsInWinningState();
}
