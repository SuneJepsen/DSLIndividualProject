package com.frameworkdsl.objects;

public class Object {
    private String _name;
    // TODO: remove field
    //private Map<String,java.lang.Object> _properties;
    private Position _position;

    public Object(String name, Position position){
        _name = name;
        _position = position;
        //_properties = new HashMap<>();
    }

    public Position getPosition() {
        return _position;
    }
    public void setPosition(Position position) {
        _position = position;
    }
    // TODO: Remove method
    //public void addProperty(String key, java.lang.Object value) {
    //    _properties.put(key,value);
    //}
    // TODO: Remove method
//    public Map<String,java.lang.Object> getProperties(){
//        return _properties;
//    }

    public String getName() {
        return _name;
    }
}
